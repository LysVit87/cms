<?php


error_reporting(E_ALL^E_NOTICE);


include 'pdoconfig.php';


$arr = array();
$validates = Comment::validate($arr);

if($validates)
{    
    $inputDb = new pdoconfig;
    $inputDb->addComment($arr['name'], $arr['body']);
       
	$arr['dt'] = date('r',time());
        $arr['id'] = $inputDb->lastInsertId();
	$arr = array_map('stripslashes',$arr);	
	$insertedComment = new Comment($arr);

	echo json_encode(array('status'=>1,'html'=>$insertedComment->markup()));
}
else
{
	echo '{"status":0,"errors":'.json_encode($arr).'}';
}

?>