<?php


include_once 'comment.class.php';
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PDOConfig
 *
 * @author lysvit87
 */
class pdoconfig extends PDO { 
    
    private $engine; 
    private $host; 
    private $database; 
    private $user; 
    private $pass; 
  
    public function __construct(){ 
        $this->engine = 'mysql'; 
        $this->host = 'localhost'; 
        $this->database = 'commentsystem'; 
        $this->user = 'root'; 
        $this->pass = ''; 
        $dns = $this->engine.':dbname='.$this->database.";host=".$this->host; 
        parent::__construct( $dns, $this->user, $this->pass ); 
    } 
   
    
    // Додаем коментарий
    public function addComment($Dname,$Dcomment)
    {
        $stmt = $this->prepare("INSERT INTO testcomment (name, body) VALUES (:name, :body)");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':body', $body);
        $name = $Dname;
        $body = $Dcomment;
        $stmt->execute();
    }
    
     // Выволим коментарий
    public function getComment()
    {
        $comments = array();
        
        try {
        $STH = $this->query('SELECT * from testcomment');
        $STH->setFetchMode(PDO::FETCH_ASSOC);  
  
        while($row = $STH->fetch()) 
                {  
                $comments[] = new Comment($row);
                }
 
        return $comments;  
        
               } catch (PDOException $e) {
                    print "Error!: " . $e->getMessage() . "<br/>";
                     die();
                                        }
    }
}
