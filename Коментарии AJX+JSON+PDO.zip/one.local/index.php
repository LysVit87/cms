
<?php

error_reporting(E_ALL^E_NOTICE);

include 'pdoconfig.php';
$input = new pdoconfig();
$reversed = $input->getComment();
?>

<!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <title>Простая система комментариев</title>
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <script type="text/javascript"src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
        <script type="text/javascript" src="script.js"></script>
    </head>
    <body>
       
        <div id="main">
            
<?php
foreach($reversed as $key)
{
	echo $key->markup();
}
?>

<div id="addCommentContainer">
	<p>Добавить комментарий</p>
	<form id="addCommentForm" method="post" action="">
    	<div>
        	<label for="name">Имя</label>
        	<input type="text" name="name" id="name" />
            
            
            <label for="body">Содержание комментария</label>
            <textarea name="body" id="body" cols="20" rows="5"></textarea>
            
            <input type="submit" id="submit" value="Отправить" />
        </div>
    </form>
</div>

</div>        
    </body>
</html>

