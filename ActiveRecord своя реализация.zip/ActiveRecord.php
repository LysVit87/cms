<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ActiveRecord
 * SELECT * FROM `user` WHERE `id` = 1
 *BD
 * id
 * FirsName
 * LastName
 * NymberPurch
 * @author lysvit87
 */
error_reporting(E_ALL^E_NOTICE);
require_once 'PDOConfig.php';
class ActiveRecord {
    
    static private $obj;
    static private $id;
    private $firstname;
    private $lastname;
    private $numberpurch;
    
    public function __construct($date) 
    {
        if (is_array($date))
        {
        $this->firstname = $date['firstname'];
        $this->lastname = $date['lastname'];
        $this->numberpurch = (int)$date['numberpurch'];
        }
    }

           public function get($tabl,$crit)
    {
      return self::createPDOConfig()->get($tabl,$crit);

    }
    
        public function setvalidnumber($numberpurch)
    {
           $this->Load($this->firstname,$this->lastname,$numberpurch);
        self::Update();
    }
        public function setlastname($lastname)
    {
           $this->Load($this->firstname,$lastname,  $this->numberpurch);
        self::Update();
    }

    public function setfirstname ($firstname)
    {
        $this->Load($firstname,$this->lastname,  $this->numberpurch);
        self::Update();
    }
    
     public static function validid($id)
    {
            if (self::validnull($id)) 
           {
               return $id;
           }
           
           else
           {
              if (self::isvalidint($id))
              {
                 if (self::validint($id))
                 {
                     return $id;
                 }
                 else
                 {
                     return FALSE;
                 }
              }
            else 
            {
                return FALSE;
            }
           }
    }
    
    public static function validnumber(ActiveRecord $obj)
    {
            if (self::validnull($obj->numberpurch)) 
           {
               return $obj;
           }
           
           else
           {
              if (self::isvalidint($obj->numberpurch))
              {
                 if (self::validint($obj->numberpurch))
                 {
                     return $obj;
                 }
                 else
                 {
                     return FALSE;
                 }
              }
            else 
            {
                return FALSE;
            }
           }
    }

        public static function validfirstname(ActiveRecord $obj)
    {
           if (self::validnull($obj->firstname)) 
           {
               return $obj;
           }
           
           else
           {
              if (self::isvalidstr($obj->firstname))
              {
                  if (self::validstr($obj->firstname))
                  {
                      return $obj;
                  }
           else 
            {
                return FALSE;
            }
              }
              
           else 
               {
                    return FALSE;
               }      
           }
    }
        
    
        public static function validlastname(ActiveRecord $obj)
    {
           if (self::validnull($obj->lastname)) 
           {
               return $obj;
           }
           
           else
           {
              if (self::isvalidstr($obj->lastname))
              {
                  if (self::validstr($obj->lastname))
                  {
                      return $obj;
                  }
           else 
            {
                return FALSE;
            }
              }
              
           else 
               {
                    return FALSE;
               }      
           }
    }
   
  

    public static function isvalidint($id)
    {
         if (is_int($id)) return TRUE;

    }

        public static function isvalidstr($str)
    {
       if (is_string($str)) return TRUE;
    }

    public static function validstr($str)
    {
       if (preg_match('/^[A-Za-z]+$/',$str)) return TRUE;
    }
    
      public static function validint($str)
    {
       if (preg_match('/^[\d\+]+$/',$str)) return TRUE;
    }

    public static function validnull($vnull)
    {    
        if ($vnull===null) return TRUE;
    }
    
        public function Load($firstname=null,$lastname=null,$numberpurch=null)
    {   
        $date['firstname']=$firstname;
        $date['lastname']=$lastname;
        $date['numberpurch']=$numberpurch;
        
       self::$obj=new self($date);
      if (!is_bool(self::validfirstname(self::$obj))) self::$obj->firstname;
      if (!is_bool(self::validlastname(self::$obj))) self::$obj->lastname;
      if (!is_bool(self::validnumber(self::$obj))) self::$obj->numberpurch;
     
    }

        public function ec()
    {
            var_dump(self::$obj);
      var_dump(self::$id);
      var_dump(get_class($this));
      var_dump($this);
      
    }
    public static function delete()
    {
    self::createPDOConfig()->delete(self::$id);
    }
    
    public static function Insert()
    {
    self::createPDOConfig()->Inseret(self::$id,self::$obj->firstname,self::$obj->lastname,self::$obj->numberpurch);
    }

      public static function Update()
    {
    self::createPDOConfig()->Update(self::$id,self::$obj->firstname,self::$obj->lastname,self::$obj->numberpurch);
    }
    
    public static function createPDOConfig ()
    {
        return new PDOConfig();
    }

        public static function findById($id) 
   {
       if (!is_bool(self::validid($id)))
       {
        $data = self::createPDOConfig()->getComment($id);
       if ($data) {
           self::$id=$id;
           return new self($data);
       } 
 else {
            self::$id=$id;
           return new self($data);
       }
       }

            
   }
    
}

$A=ActiveRecord::findById(34);
//$A->Load('aaa','bbb',55);
//$A->Insert();
//$A->Load('aaaa','bbbbb',555);
//$A->Update();
$A->delete();
//$A->setfirstname('a');
//$A->ec();
//$b=$A->get('numberpurch',3);


