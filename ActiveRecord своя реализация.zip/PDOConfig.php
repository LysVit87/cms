<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PDOConfig
 *
 * @author lysvit87
 */
error_reporting(E_ALL^E_NOTICE);

class PDOConfig extends PDO { 
    
    private $engine; 
    private $host; 
    private $database; 
    private $user; 
    private $pass; 
    
    public function __construct(){ 
        $this->engine = 'mysql'; 
        $this->host = 'localhost'; 
        $this->database = 'test'; 
        $this->user = 'root'; 
        $this->pass = ''; 
        $dns = $this->engine.':dbname='.$this->database.";host=".$this->host; 
        parent::__construct( $dns, $this->user, $this->pass ); 
    } 

        public  function getComment($id)
    {
        $comments = array();
        
        try {
        $STH = $this->prepare("SELECT * from user WHERE id =(:id)");
        $STH->bindParam(':id', $id);
        $STH->setFetchMode(PDO::FETCH_ASSOC);  
        $STH->execute();
      $comments = $STH->fetch();

        return $comments;  
        
               } catch (PDOException $e) {
                    print "Error!: " . $e->getMessage() . "<br/>";
                     die();
                                        }
    }
    
        public function Inseret($id,$firstname,$lastname,$numberpurch)
    {
        $stmt = $this->prepare("INSERT INTO user (id,firstname,lastname,numberpurch) VALUES (:id,:firstname,:lastname,:numberpurch)");
        $stmt->bindParam(':id', $id);
       $stmt->bindParam(':firstname', $firstname);
        $stmt->bindParam(':lastname', $lastname);
        $stmt->bindParam(':numberpurch', $numberpurch);
        $stmt->execute();
    }
            public function Update($id,$firstname,$lastname,$numberpurch)
    {
        $stmt = $this->prepare("UPDATE user SET firstname=(:firstname),lastname=(:lastname),numberpurch=(:numberpurch) WHERE id =(:id);");
        $stmt->bindParam(':id', $id);
       $stmt->bindParam(':firstname', $firstname);
       $stmt->bindParam(':lastname', $lastname);
       $stmt->bindParam(':numberpurch', $numberpurch);
        $stmt->execute();
    }
    
         public function delete($id)
    {
         $STH = $this->prepare("DELETE from user WHERE id =(:id)");
        $STH->bindParam(':id', $id);
        $STH->execute();
    }
    
             public function get($tabl,$crit)
    {
        $STH = $this->prepare("SELECT * FROM user WHERE $tabl = $crit");
       $STH->setFetchMode(PDO::FETCH_ASSOC); 
        $STH->execute();
        $comments = $STH->fetch();
        $arr=$comments[$tabl];
        return $arr; 
    }
}


