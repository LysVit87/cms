﻿<?php
require_once "../xhprof.local/xhprof_start.php"; 
$p_base = dirname(__FILE__).'/application/promsite.php';

require_once($p_base);

Base::createWebApplication();

require_once "../xhprof.local/xhprof_stop.php" ;