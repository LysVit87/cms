<?php

class View
{
	

	function generate($content_view, $template_view, $data = null)
	{
		
		
		if(is_array($data)) {
			
			// преобразуем элементы массива в переменные
			extract($data);
		}
		
		
		/*
		динамически подключаем общий шаблон (вид),
		внутри которого будет встраиваться вид
		для отображения контента конкретной страницы.
		*/
		include Site_PATH."/views/".$template_view;
	}
}

class View1 {
	
	private $dir_tmpl;
	
	public function __construct($dir_tmpl) {
		$this->dir_tmpl = $dir_tmpl;
	}
	
	public function render($file, $params, $return = false) {
		$template = $this->dir_tmpl.$file.".tpl";
		extract($params);
		ob_start();
		include($template);
		if ($return) return ob_get_clean();
		else echo ob_get_clean();
	}
}