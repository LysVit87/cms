<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of URL
 *
 * 
 * 		try {
			if (class_exists($controller_name)) $controller = new $controller_name();
			if (method_exists($controller, $action_name)) $controller->$action_name();
			else throw new Exception();
		} catch (Exception $e) {
			//if ($e->getMessage() != "ACCESS_DENIED") $controller->action404();
		}
 * @author lysvit87
 */
class URL  
{
public $controller_name;
public	$action_name ;
    
 public   function __construct() 
    {
        $this->controller_name = 'Main';
	$this->action_name = 'index';
    }

    static function  ErrorPage404()
	{
        $host = 'http://'.$_SERVER['HTTP_HOST'].'/';
        header('HTTP/1.1 404 Not Found');
		header("Status: 404 Not Found");
		header('Location:'.$host.'Error');
    }
    
 function Big_Title_Point($name)
    {
        $first = mb_substr($name,0,1, 'UTF-8');
        $last = mb_substr($name,1);
        $first = mb_strtoupper($first, 'UTF-8');
        $last = mb_strtolower($last, 'UTF-8');
        $name_two = $first.$last;
        
        return $name_two;

    }
    
public  function AddPrefixModels($controller_name) 
{
   return  'Model_'.$controller_name;
   
}

public  function AddPrefixAction() 
{
   return $this->action_name = 'action_'.$this->action_name;
   
}

protected function AddFileModels() 
{ 
  $model_file = strtolower($this->AddPrefixModels($this->controller_name)).'.php';
  $model_path = Site_PATH."/models/".$model_file;
   
  try {
if(file_exists($model_path)) include_once Site_PATH."/models/".$model_file;    
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}             
 }

protected function AddFileControlles($controller_name) 
{
$controller_name = $this->Big_Title_Point($controller_name).'Controller';
$controller_file = $controller_name.'.php';
$controller_path = Site_PATH."/controllers/".$controller_file;
$this->getControllerFile($controller_path, $controller_file);
return $controller_name;               
}

protected function getControllerFile($controller_path,$controller_file)
{
  try {

if(file_exists($controller_path)) include_once Site_PATH."/controllers/".$controller_file;
else URL::ErrorPage404();
    
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}     
}

public function start()
    {             
    $this->rout();	    
    $this->AddPrefixAction();    
    $this->AddFileModels();
    $this->controller_name = $this->AddFileControlles($this->controller_name);  
$action = $this->action_name;
try {
    if (class_exists($this->controller_name)) $controller = new $this->controller_name();
    if (method_exists($controller, $action)) $controller->$action(); else URL::ErrorPage404();

} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}
}
        
private function  rout ()
        {
        $routes = explode('/', $_SERVER['REQUEST_URI']);
                	
	if ( !empty($routes[1]) )
            {	
           $this->controller_name = $routes[1];
            }     
            
	if ( !empty($routes[2]) )
            {
            $this->action_name = $routes[2];
            }
        }

}