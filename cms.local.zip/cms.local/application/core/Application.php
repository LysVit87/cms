<?php
//---------------------class Application----------------------------------------
class Application 
{

     public function __construct() 
    {
         $a = new URL;
         $a->start();
    }

 



    //put your code here
}
