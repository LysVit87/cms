<?php
 //---------------------defined------------------------------------------------- 
defined('Site_PATH') or define('Site_PATH',dirname(__FILE__));
defined('Site_DEBUG') or define('Site_DEBUG',true);
 //-----------------class Base-------------------------------------------------- 
class Base
{
    public static $classMap=array();
    
    public static $enableIncludePath=true;
    
    private static $_includePaths;	
    
    private static $_coreClasses = array (
        'Controller' => '/core/controller.php',
        'Model' => '/core/model.php',
        'View' => '/core/view.php',
        'Application' => '/core/Application.php',
        'URL' => '/core/URL.php', 
    );
  
 //----------------------------------------------------------------------------- 
public static function createWebApplication($config=null)
    {
	return self::createApplication('Application',$config);
    }
 //-----------------------------------------------------------------------------        
public static function createApplication($class,$config=null)
    {
        return new $class($config);
    }	
 //-----------------------------------------------------------------------------     
public static function autoload($className)
    {
	if(isset(self::$classMap[$className]))
            include(self::$classMap[$className]);
        
	elseif(isset(self::$_coreClasses[$className]))
            include(Site_PATH.self::$_coreClasses[$className]);
        
	else
	{
            if(strpos($className,'\\')===false)  
            {
            if(self::$enableIncludePath===false)
            {
                
            foreach(self::$_includePaths as $path)
            {
            $classFile=$path.DIRECTORY_SEPARATOR.$className.'.php';
            
            if(is_file($classFile))
            {
		include($classFile);
                
            if(Site_DEBUG && basename(realpath($classFile))!==$className.'.php')
                    
            throw new Exception ('Ошыбка загрузки');
		break;
            }
            }
            }
            
            else
		include($className.'.php');
            
            }
            
            else  
            {
		$namespace=str_replace('\\','.',ltrim($className,'\\'));
                
            if(($path=self::getPathOfAlias($namespace))!==false)
                    
		include($path.'.php');
            
            else
		return false;
            }
                return class_exists($className,false) || interface_exists($className,false);
            }
            return true;
    }
 //----------------------------------------------------------------------------- 
}
//------------------------------------------------------------------------------
spl_autoload_register(array('Base','autoload'));
