<?php

// подключаем файлы ядра
//require_once 'core/model.php';
//require_once 'core/view.php';
//require_once 'core/controller.php';

mb_internal_encoding("UTF-8");
error_reporting(E_ALL);


require_once 'Base.php';

